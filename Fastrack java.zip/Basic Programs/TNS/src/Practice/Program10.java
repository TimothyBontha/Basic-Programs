package Practice;

public class Program10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 33, y = 55, a = -15, b = -23, sum, s;    
		sum=Integer.sum(x, y);  
		//returns the sum of x and y  
		System.out.println("The sum of x and y is: " +sum);    
		s=Integer.sum(a, b);  
		System.out.println("The sum of x and y is: " +s);  
		}    
		
	}


