package Practice;

public class Program12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   String s1="Sachin ";  
		   String s2="Tendulkar";  
		   String s3=s1.concat(s2);  
		   System.out.println(s3);//Sachin Tendulkar  
		  }  
		
	}


