package Practice;
import java.util.Scanner;
public class Program11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int n, count = 1;   
	      float  xF, averageF, sumF = 0;   
	      Scanner sc = new Scanner(System.in);     
	      System.out.println("Enter the value of n");  
	      n = sc.nextInt();  
	      while (count <= n)   
	             {   
	                  System.out.println("Enter the "+count+" number?");  
	                  xF = sc.nextInt();  
	                  sumF += xF;   
	                  ++count;   
	             }   
	                  averageF = sumF/n;   
	        System.out.println("The Average is"+averageF);  
	    }    
	
	}


